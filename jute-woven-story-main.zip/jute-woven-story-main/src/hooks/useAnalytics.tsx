import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

export function useAnalytics() {
  const location = useLocation();

  useEffect(() => {
    const trackVisit = async () => {
      try {
        // Get device info
        const device = /Mobile|Android|iPhone/i.test(navigator.userAgent) ? 'mobile' : 'desktop';
        
        // Get traffic source from referrer
        let traffic_source = 'direct';
        if (document.referrer) {
          const referrer = new URL(document.referrer);
          if (referrer.hostname.includes('google')) traffic_source = 'search';
          else if (referrer.hostname.includes('facebook') || referrer.hostname.includes('instagram')) traffic_source = 'social';
          else if (referrer.hostname !== window.location.hostname) traffic_source = 'referral';
        }

        // Insert visitor log (IP and country would need backend/edge function for accuracy)
        await supabase.from('visitors_logs').insert({
          page: location.pathname,
          device,
          traffic_source,
        });
      } catch (error) {
        console.error('Analytics tracking error:', error);
      }
    };

    // Track page visit
    trackVisit();
  }, [location.pathname]);
}
