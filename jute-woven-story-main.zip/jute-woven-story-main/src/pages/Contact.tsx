import { Mail, Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

const Contact = () => {
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message sent!",
      description: "We'll get back to you as soon as possible.",
    });
  };

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-heading text-5xl md:text-6xl font-bold mb-4 animate-fade-in">
            Get in Touch
          </h1>
          <p className="text-xl max-w-2xl mx-auto animate-slide-up">
            Have questions or want to discuss a custom order? We'd love to hear from you.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Contact Form */}
            <div className="animate-fade-in">
              <h2 className="font-heading text-3xl font-bold mb-6 text-primary">
                Send Us a Message
              </h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-2 text-foreground">
                    Name
                  </label>
                  <Input
                    id="name"
                    type="text"
                    required
                    placeholder="Your name"
                    className="w-full"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-2 text-foreground">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    required
                    placeholder="your@email.com"
                    className="w-full"
                  />
                </div>
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium mb-2 text-foreground">
                    Subject
                  </label>
                  <Input
                    id="subject"
                    type="text"
                    required
                    placeholder="How can we help?"
                    className="w-full"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-2 text-foreground">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    required
                    placeholder="Tell us more about your inquiry..."
                    className="w-full min-h-[150px]"
                  />
                </div>
                <Button type="submit" size="lg" className="w-full">
                  Send Message
                </Button>
              </form>
            </div>

            {/* Contact Information */}
            <div className="animate-slide-up">
              <h2 className="font-heading text-3xl font-bold mb-6 text-primary">
                Contact Information
              </h2>
              <div className="space-y-6 mb-8">
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold mb-2 text-foreground">Head Office:</h3>
                    <p className="text-muted-foreground mb-4">
                      House # 16, Level 6, Road # 13<br />
                      Sector # 4, Uttara<br />
                      Dhaka, Bangladesh
                    </p>
                    <h3 className="font-semibold mb-2 text-foreground">Factory:</h3>
                    <p className="text-muted-foreground">
                      Haripur Chandanpath<br />
                      Rangpur Sadar, Rangpur
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Phone className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold mb-1 text-foreground">Phone</h3>
                    <p className="text-muted-foreground">
                      <a href="tel:+8801713727871" className="hover:text-primary transition-colors">+88 01713 727871</a>
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Mail className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold mb-1 text-foreground">Email</h3>
                    <p className="text-muted-foreground">
                      <a href="mailto:info@jutesourcebd.com" className="hover:text-primary transition-colors">info@jutesourcebd.com</a>
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold mb-1 text-foreground">Website</h3>
                    <p className="text-muted-foreground">
                      <a href="https://jutesourcebd.com" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">jutesourcebd.com</a>
                    </p>
                  </div>
                </div>
              </div>

              {/* Map Placeholder */}
              <div className="bg-muted rounded-lg h-64 flex items-center justify-center">
                <p className="text-muted-foreground">Map would be embedded here</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Business Hours */}
      <section className="py-16 bg-card">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-heading text-3xl font-bold mb-6 text-primary">
              Business Hours
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-6 bg-background rounded-lg">
                <h3 className="font-semibold mb-2 text-foreground">Monday - Friday</h3>
                <p className="text-muted-foreground">9:00 AM - 6:00 PM</p>
              </div>
              <div className="p-6 bg-background rounded-lg">
                <h3 className="font-semibold mb-2 text-foreground">Saturday</h3>
                <p className="text-muted-foreground">10:00 AM - 4:00 PM</p>
              </div>
            </div>
            <p className="mt-6 text-muted-foreground">Closed on Sundays and public holidays</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
