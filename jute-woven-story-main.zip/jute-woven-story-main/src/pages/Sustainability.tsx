import { Target } from "lucide-react";

const Sustainability = () => {
  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-heading text-5xl md:text-6xl font-bold mb-4 animate-fade-in">
            Sustainability & Impact
          </h1>
          <p className="text-xl max-w-2xl mx-auto animate-slide-up">
            Good business is kind to both people and planet
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center mb-8 animate-fade-in">
              <Target className="w-12 h-12 text-primary mr-4" />
              <h2 className="font-heading text-4xl font-bold text-primary">Our Commitment</h2>
            </div>
            <div className="prose prose-lg max-w-none text-muted-foreground animate-slide-up">
              <p className="text-lg mb-8">
                We believe that good business is kind to both people and planet. Our production process ensures:
              </p>
              <ul className="space-y-4 text-lg">
                <li className="flex items-start">
                  <span className="text-primary mr-3">🌿</span>
                  <span>Fair wages for rural artisans</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-3">♻️</span>
                  <span>Zero plastic and low-waste packaging</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-3">🌱</span>
                  <span>Renewable material sourcing</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-3">💚</span>
                  <span>Eco-friendly dyeing and finishing</span>
                </li>
              </ul>
              <p className="text-xl font-semibold text-foreground mt-10 p-6 bg-card rounded-lg">
                Every purchase helps support rural women, artisans, and communities in Bangladesh.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Sustainability;
