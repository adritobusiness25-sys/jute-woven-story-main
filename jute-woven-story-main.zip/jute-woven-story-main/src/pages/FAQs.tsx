import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQs = () => {
  const faqs = [
    {
      question: "What products do you offer?",
      answer: "We offer a wide range of jute products including bags, yarn, home décor items, packaging solutions, rugs, carpets, and lifestyle accessories. All products are 100% natural, biodegradable, and sustainably produced.",
    },
    {
      question: "Do you provide custom designs?",
      answer: "Yes! We specialize in custom design services for bulk orders. Whether you need branded bags, specialized packaging, or unique home décor, our experienced team can work with you to create products that meet your specific requirements.",
    },
    {
      question: "Where are your materials sourced from?",
      answer: "All our jute is ethically sourced from local farms in Bangladesh through direct partnerships with over 200 farmers. We ensure fair trade practices and sustainable farming methods throughout our supply chain.",
    },
    {
      question: "Are your products truly eco-friendly?",
      answer: "Absolutely. Jute is a 100% biodegradable natural fiber. Our production process uses minimal water, no harmful chemicals, and all waste materials are composted. We're certified by international sustainability organizations.",
    },
    {
      question: "What is your minimum order quantity?",
      answer: "For custom orders, our minimum quantity varies by product type. Typically, MOQ ranges from 500-1000 pieces. For standard products, we accept smaller orders through our regular sales channels. Contact us for specific details.",
    },
    {
      question: "Do you ship internationally?",
      answer: "Yes, we ship to over 40 countries worldwide. We use eco-friendly packaging and work with carbon-neutral shipping partners whenever possible. Shipping costs and delivery times vary by destination.",
    },
    {
      question: "How long does production take?",
      answer: "Standard products are usually in stock and ship within 3-5 business days. Custom orders typically require 4-6 weeks for production, depending on complexity and quantity. We'll provide a detailed timeline when you place your order.",
    },
    {
      question: "What certifications do you hold?",
      answer: "We're proud to hold ISO 9001 certification for quality management, Fair Trade certification, GOTS (Global Organic Textile Standard) certification, and are recognized as a carbon-neutral manufacturer.",
    },
    {
      question: "Can I visit your facility?",
      answer: "We welcome visitors! Our facility tours showcase our production process, from raw jute to finished products. Tours must be scheduled in advance. Contact us to arrange a visit.",
    },
    {
      question: "How can I become a distributor?",
      answer: "We're always looking for partners who share our commitment to sustainability. Please reach out through our contact form with details about your business, and our partnership team will get in touch with you.",
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-heading text-5xl md:text-6xl font-bold mb-4 animate-fade-in">
            Frequently Asked Questions
          </h1>
          <p className="text-xl max-w-2xl mx-auto animate-slide-up">
            Find answers to common questions about our products, services, and sustainability practices
          </p>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card rounded-lg px-6 shadow-md animate-fade-in"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <AccordionTrigger className="font-heading text-lg font-semibold text-foreground hover:text-primary">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* Still Have Questions */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-heading text-4xl font-bold mb-6 text-primary">
              Still Have Questions?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Can't find the answer you're looking for? Our friendly team is here to help.
            </p>
            <a
              href="/contact"
              className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-colors"
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FAQs;
