import ProductCard from "@/components/ProductCard";
import yarnImage from "@/assets/product-yarn.jpg";

const BraidingMaterials = () => {
  const materials = [
    {
      image: yarnImage,
      title: "Jute Yarn",
      description: "High-quality natural fiber yarn for textiles, crafts, and industrial applications. Available in various thicknesses and grades.",
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-heading text-5xl md:text-6xl font-bold mb-4 animate-fade-in">
            Braiding Materials
          </h1>
          <p className="text-xl max-w-2xl mx-auto animate-slide-up">
            Premium jute yarn for all your textile and industrial needs
          </p>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {materials.map((material, index) => (
              <div
                key={index}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <ProductCard {...material} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Custom Orders Section */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-heading text-4xl font-bold mb-6 text-primary animate-fade-in">
              Custom Specifications Available
            </h2>
            <p className="text-lg text-muted-foreground mb-8 animate-slide-up">
              We can produce jute yarn according to your specific requirements - thickness, twist, color, and finish. Perfect for industrial applications, textile manufacturing, and craft projects.
            </p>
            <a
              href="/inquiries"
              className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-colors"
            >
              Request Quote
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BraidingMaterials;
