import { Mail, MessageCircle, Globe } from "lucide-react";

const WorkWithUs = () => {
  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-heading text-5xl md:text-6xl font-bold mb-4 animate-fade-in">
            Work With Us
          </h1>
          <p className="text-xl max-w-2xl mx-auto animate-slide-up">
            Let's create something sustainable together
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="font-heading text-3xl font-bold mb-8 text-primary animate-fade-in">
              Looking for a reliable natural fiber supplier from Bangladesh?
            </h2>
            <p className="text-xl text-muted-foreground mb-12 animate-slide-up">
              Whether you're an importer, wholesaler, or retail brand, we're here to support your sustainable sourcing needs.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
              <div className="bg-card p-8 rounded-lg shadow-lg animate-fade-in">
                <Mail className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="font-heading text-xl font-semibold mb-3 text-foreground">Email</h3>
                <a 
                  href="mailto:info@jutesourcebd.com" 
                  className="text-primary hover:text-accent transition-colors text-lg"
                >
                  info@jutesourcebd.com
                </a>
              </div>

              <div className="bg-card p-8 rounded-lg shadow-lg animate-fade-in" style={{ animationDelay: "0.1s" }}>
                <MessageCircle className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="font-heading text-xl font-semibold mb-3 text-foreground">WhatsApp</h3>
                <a 
                  href="https://wa.me/8801840650201" 
                  className="text-primary hover:text-accent transition-colors text-lg"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  +880 1840 650201
                </a>
              </div>

              <div className="bg-card p-8 rounded-lg shadow-lg animate-fade-in" style={{ animationDelay: "0.2s" }}>
                <Globe className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="font-heading text-xl font-semibold mb-3 text-foreground">Website</h3>
                <a 
                  href="http://www.jutesourcebd.com" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-primary hover:text-accent transition-colors text-lg"
                >
                  www.jutesourcebd.com
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default WorkWithUs;
