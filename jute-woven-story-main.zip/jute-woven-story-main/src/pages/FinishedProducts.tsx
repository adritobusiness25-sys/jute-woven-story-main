import ProductCard from "@/components/ProductCard";
import bagsImage from "@/assets/product-bags.jpg";
import decorImage from "@/assets/product-decor.jpg";
import packagingImage from "@/assets/product-packaging.jpg";
import rugsImage from "@/assets/product-rugs.jpg";
import lifestyleImage from "@/assets/product-lifestyle.jpg";

const FinishedProducts = () => {
  const products = [
    {
      image: bagsImage,
      title: "Jute Bags",
      description: "Durable, reusable shopping bags perfect for eco-conscious consumers. Available in various sizes and designs.",
    },
    {
      image: decorImage,
      title: "Home Décor",
      description: "Elegant placemats, coasters, and table runners that bring natural warmth to any space.",
    },
    {
      image: packagingImage,
      title: "Packaging Solutions",
      description: "Sustainable packaging materials for businesses committed to reducing plastic waste.",
    },
    {
      image: rugsImage,
      title: "Jute Rugs & Carpets",
      description: "Handwoven floor coverings that combine durability with timeless aesthetic appeal.",
    },
    {
      image: lifestyleImage,
      title: "Lifestyle Products",
      description: "Modern accessories and everyday items crafted from natural jute fiber.",
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-heading text-5xl md:text-6xl font-bold mb-4 animate-fade-in">
            Finished Products
          </h1>
          <p className="text-xl max-w-2xl mx-auto animate-slide-up">
            Ready-to-use sustainable jute products for modern living
          </p>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product, index) => (
              <div
                key={index}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <ProductCard {...product} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Custom Orders Section */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-heading text-4xl font-bold mb-6 text-primary animate-fade-in">
              Custom Designs Available
            </h2>
            <p className="text-lg text-muted-foreground mb-8 animate-slide-up">
              Need something specific? We offer custom design services for bulk orders. Whether you're looking for branded bags, specialized packaging, or unique home décor, our team can bring your vision to life with sustainable jute solutions.
            </p>
            <a
              href="/inquiries"
              className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-colors"
            >
              Get in Touch
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FinishedProducts;
