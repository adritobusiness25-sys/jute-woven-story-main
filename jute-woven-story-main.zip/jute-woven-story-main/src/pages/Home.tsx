import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Recycle, Globe, Handshake, ArrowRight } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import BlogCard from "@/components/BlogCard";
import heroImage from "@/assets/hero-jute-field.jpg";
import weavingImage from "@/assets/weaving-craft.jpg";
import bagsImage from "@/assets/product-bags.jpg";
import yarnImage from "@/assets/product-yarn.jpg";
import decorImage from "@/assets/product-decor.jpg";
import packagingImage from "@/assets/product-packaging.jpg";
import rugsImage from "@/assets/product-rugs.jpg";
import lifestyleImage from "@/assets/product-lifestyle.jpg";

const Home = () => {
  const featuredProducts = [
    { image: bagsImage, title: "Jute Bags", description: "Eco-friendly shopping solutions" },
    { image: yarnImage, title: "Jute Yarn", description: "Natural textile materials" },
    { image: decorImage, title: "Home Décor", description: "Sustainable living essentials" },
    { image: packagingImage, title: "Packaging", description: "Green business solutions" },
    { image: rugsImage, title: "Jute Rugs", description: "Handwoven floor coverings" },
    { image: lifestyleImage, title: "Lifestyle", description: "Modern eco products" },
  ];

  const blogPosts = [
    {
      id: "1",
      image: heroImage,
      title: "The Journey from Field to Fabric",
      excerpt: "Discover how our artisans transform raw jute into beautiful, sustainable products.",
      date: "March 15, 2025",
    },
    {
      id: "2",
      image: weavingImage,
      title: "Why Jute is the Future of Sustainable Living",
      excerpt: "Learn about the environmental benefits of choosing jute over synthetic materials.",
      date: "March 10, 2025",
    },
    {
      id: "3",
      image: bagsImage,
      title: "Supporting Local Farmers Through Fair Trade",
      excerpt: "How our commitment to ethical sourcing creates positive change in communities.",
      date: "March 5, 2025",
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-primary/70 via-primary/50 to-background/90" />
        </div>
        
        <div className="relative z-10 container mx-auto px-4 text-center animate-fade-in">
          <h1 className="font-heading text-5xl md:text-7xl font-bold text-card mb-6">
            We weave nature into<br />sustainable products
          </h1>
          <p className="text-xl md:text-2xl text-card/90 mb-8 max-w-3xl mx-auto">
            Jute Source BD crafts 100% natural jute solutions for packaging, décor, and lifestyle
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/finished-products">
              <Button size="lg" variant="secondary" className="min-w-[200px]">
                Explore Our Products
              </Button>
            </Link>
            <Link to="/why-choose-us">
              <Button size="lg" variant="outline" className="min-w-[200px] bg-card/10 text-card border-card hover:bg-card hover:text-primary">
                Learn More
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Who We Are */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <img
                src={weavingImage}
                alt="Jute weaving craftsmanship"
                className="rounded-lg shadow-2xl"
              />
            </div>
            <div className="animate-slide-up">
              <h2 className="font-heading text-4xl md:text-5xl font-bold mb-6 text-primary">
                Sustainability woven into every fiber
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                At Jute Source BD, we combine traditional craftsmanship with modern innovation to create products that honor both people and planet. Every piece tells a story of ethical sourcing, skilled artisanship, and environmental care.
              </p>
              <p className="text-lg text-muted-foreground mb-8">
                From our partnerships with local farmers to our eco-friendly production methods, we're committed to building a sustainable future—one jute fiber at a time.
              </p>
              <Link to="/why-choose-us">
                <Button size="lg" className="group">
                  About Us
                  <ArrowRight className="ml-2 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 animate-fade-in">
            <h2 className="font-heading text-4xl md:text-5xl font-bold mb-4 text-primary">
              Featured Products
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Discover our collection of handcrafted jute products, each designed with sustainability and style in mind
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {featuredProducts.map((product, index) => (
              <div key={index} className="animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <ProductCard {...product} />
              </div>
            ))}
          </div>
          <div className="text-center">
            <Link to="/finished-products">
              <Button size="lg" variant="outline">
                View All Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="font-heading text-4xl md:text-5xl font-bold mb-4 text-primary">
              Our Craftsmanship Journey
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              From field to finished product, every step is guided by quality and sustainability
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
            {[
              { step: "Harvest", description: "Ethically sourced from local farms" },
              { step: "Weave", description: "Traditional handloom techniques" },
              { step: "Design", description: "Modern aesthetic meets function" },
              { step: "Deliver", description: "Eco-friendly packaging & shipping" },
              { step: "Inspire", description: "Creating sustainable lifestyles" },
            ].map((item, index) => (
              <div key={index} className="text-center animate-slide-up" style={{ animationDelay: `${index * 0.1}s` }}>
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-heading text-2xl font-bold">
                  {index + 1}
                </div>
                <h3 className="font-heading text-xl font-semibold mb-2 text-foreground">
                  {item.step}
                </h3>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sustainability Impact */}
      <section className="py-20 bg-jute-green-light text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="font-heading text-4xl md:text-5xl font-bold mb-4">
              Our Environmental Commitment
            </h2>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              Every product we create contributes to a healthier planet
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center animate-slide-up">
              <Recycle className="w-16 h-16 mx-auto mb-6" />
              <h3 className="font-heading text-2xl font-semibold mb-4">
                100% Biodegradable
              </h3>
              <p className="opacity-90">
                All our products naturally decompose, leaving zero environmental footprint
              </p>
            </div>
            <div className="text-center animate-slide-up" style={{ animationDelay: "0.1s" }}>
              <Globe className="w-16 h-16 mx-auto mb-6" />
              <h3 className="font-heading text-2xl font-semibold mb-4">
                Eco-Friendly Production
              </h3>
              <p className="opacity-90">
                Minimal water usage and zero chemical processing in our manufacturing
              </p>
            </div>
            <div className="text-center animate-slide-up" style={{ animationDelay: "0.2s" }}>
              <Handshake className="w-16 h-16 mx-auto mb-6" />
              <h3 className="font-heading text-2xl font-semibold mb-4">
                Supporting Local Farmers
              </h3>
              <p className="opacity-90">
                Fair trade practices ensuring sustainable livelihoods for farming communities
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Blog Preview */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 animate-fade-in">
            <h2 className="font-heading text-4xl md:text-5xl font-bold mb-4 text-primary">
              From the Fields to the Future
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Stories, insights, and updates from the world of sustainable jute
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {blogPosts.map((post, index) => (
              <div key={post.id} className="animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <BlogCard {...post} />
              </div>
            ))}
          </div>
          <div className="text-center">
            <Link to="/blog">
              <Button size="lg" variant="outline">
                View All Posts
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
