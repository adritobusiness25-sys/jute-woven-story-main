import { Users } from "lucide-react";

const WhyChooseUs = () => {
  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-heading text-5xl md:text-6xl font-bold mb-4 animate-fade-in">
            Why Choose Us
          </h1>
          <p className="text-xl max-w-2xl mx-auto animate-slide-up">
            Authentic craftsmanship meets modern quality standards
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center mb-8 animate-fade-in">
              <Users className="w-12 h-12 text-primary mr-4" />
              <h2 className="font-heading text-4xl font-bold text-primary">Why Choose Jute Source BD?</h2>
            </div>
            <div className="prose prose-lg max-w-none text-muted-foreground animate-slide-up">
              <ul className="space-y-4 list-none text-lg">
                <li className="flex items-start">
                  <span className="text-primary mr-3 text-2xl">✅</span>
                  <span className="mt-1">Authentic Bangladeshi craftsmanship</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-3 text-2xl">✅</span>
                  <span className="mt-1">100% natural, biodegradable materials</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-3 text-2xl">✅</span>
                  <span className="mt-1">Export-grade quality and durability</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-3 text-2xl">✅</span>
                  <span className="mt-1">OEM/ODM customization service</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-3 text-2xl">✅</span>
                  <span className="mt-1">Fast communication & reliable delivery</span>
                </li>
              </ul>
              <p className="text-xl font-semibold text-foreground mt-8 p-6 bg-background rounded-lg">
                We don't just manufacture jute — we build trust through transparency and partnership through quality.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default WhyChooseUs;
