import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

const ChatboxPage = () => {
  const [chatSettings, setChatSettings] = useState<any>(null);
  const [config, setConfig] = useState<any>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchChatSettings();
  }, []);

  const fetchChatSettings = async () => {
    const { data } = await supabase.from('chat_settings').select('*').single();
    if (data) {
      setChatSettings(data);
      setConfig(data.config || {});
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      if (chatSettings) {
        await supabase
          .from('chat_settings')
          .update({
            type: chatSettings.type,
            config,
            active: chatSettings.active,
          })
          .eq('id', chatSettings.id);
      } else {
        await supabase.from('chat_settings').insert({
          type: 'whatsapp',
          config,
          active: false,
        });
      }
      toast.success('Chatbox settings saved');
      fetchChatSettings();
    } catch (error: any) {
      toast.error(error.message);
    }
    setLoading(false);
  };

  if (!chatSettings) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-heading font-bold">Chatbox Settings</h2>

      <Card>
        <CardHeader>
          <CardTitle>Configure Chat Widget</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Chat Type</Label>
            <Select
              value={chatSettings.type}
              onValueChange={(value) => setChatSettings({ ...chatSettings, type: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="whatsapp">WhatsApp</SelectItem>
                <SelectItem value="messenger">Messenger</SelectItem>
                <SelectItem value="telegram">Telegram</SelectItem>
                <SelectItem value="tawk">Tawk.to</SelectItem>
                <SelectItem value="crisp">Crisp</SelectItem>
                <SelectItem value="custom">Custom Script</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {chatSettings.type === 'whatsapp' && (
            <>
              <div>
                <Label>Phone Number (with country code)</Label>
                <Input
                  value={config.phone || ''}
                  onChange={(e) => setConfig({ ...config, phone: e.target.value })}
                  placeholder="+1234567890"
                />
              </div>
              <div>
                <Label>Welcome Message</Label>
                <Input
                  value={config.welcomeMessage || ''}
                  onChange={(e) => setConfig({ ...config, welcomeMessage: e.target.value })}
                  placeholder="Hello! How can we help you?"
                />
              </div>
            </>
          )}

          <div className="flex items-center space-x-2">
            <Switch
              checked={chatSettings.active}
              onCheckedChange={(checked) =>
                setChatSettings({ ...chatSettings, active: checked })
              }
            />
            <Label>Enable Chat Widget on Site</Label>
          </div>

          <Button onClick={handleSave} disabled={loading}>
            Save Chatbox Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChatboxPage;
