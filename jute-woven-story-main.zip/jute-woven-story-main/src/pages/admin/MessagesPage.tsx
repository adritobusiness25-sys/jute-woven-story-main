import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Mail, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

const MessagesPage = () => {
  const [messages, setMessages] = useState<any[]>([]);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    const { data } = await supabase
      .from('messages')
      .select('*')
      .order('created_at', { ascending: false });
    setMessages(data || []);
  };

  const toggleRead = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'read' ? 'unread' : 'read';
    await supabase.from('messages').update({ status: newStatus }).eq('id', id);
    toast.success(`Marked as ${newStatus}`);
    fetchMessages();
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this message?')) {
      await supabase.from('messages').delete().eq('id', id);
      toast.success('Message deleted');
      fetchMessages();
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-heading font-bold">Contact Messages</h2>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Message</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {messages.map((msg) => (
              <TableRow key={msg.id}>
                <TableCell className="font-medium">{msg.name}</TableCell>
                <TableCell>{msg.email}</TableCell>
                <TableCell className="max-w-xs truncate">{msg.message}</TableCell>
                <TableCell>
                  <Badge variant={msg.status === 'read' ? 'secondary' : 'default'}>
                    {msg.status}
                  </Badge>
                </TableCell>
                <TableCell>{new Date(msg.created_at).toLocaleDateString()}</TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => toggleRead(msg.id, msg.status)}
                    >
                      <Mail className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(msg.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
};

export default MessagesPage;
