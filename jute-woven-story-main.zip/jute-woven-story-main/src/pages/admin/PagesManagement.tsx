import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Pencil } from 'lucide-react';
import { toast } from 'sonner';
import { Textarea } from '@/components/ui/textarea';

const PagesManagement = () => {
  const [pages, setPages] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [editPage, setEditPage] = useState<any>(null);

  useEffect(() => {
    fetchPages();
  }, []);

  const fetchPages = async () => {
    const { data } = await supabase
      .from('pages')
      .select('*')
      .order('menu_order', { ascending: true });
    setPages(data || []);
  };

  const handleSave = async () => {
    try {
      await supabase
        .from('pages')
        .update({
          title: editPage.title,
          hero_text: editPage.hero_text,
          visible: editPage.visible,
          menu_order: editPage.menu_order,
        })
        .eq('id', editPage.id);
      toast.success('Page updated');
      fetchPages();
      setOpen(false);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-heading font-bold">Page Management</h2>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Page Name</TableHead>
              <TableHead>Slug</TableHead>
              <TableHead>Visible</TableHead>
              <TableHead>Order</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {pages.map((page) => (
              <TableRow key={page.id}>
                <TableCell className="font-medium">{page.name}</TableCell>
                <TableCell>{page.slug}</TableCell>
                <TableCell>{page.visible ? 'Yes' : 'No'}</TableCell>
                <TableCell>{page.menu_order}</TableCell>
                <TableCell>
                  <Dialog open={open && editPage?.id === page.id} onOpenChange={setOpen}>
                    <DialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setEditPage(page);
                          setOpen(true);
                        }}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Edit {page.name}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Title</Label>
                          <Input
                            value={editPage?.title || ''}
                            onChange={(e) =>
                              setEditPage({ ...editPage, title: e.target.value })
                            }
                          />
                        </div>
                        <div>
                          <Label>Hero Text</Label>
                          <Textarea
                            value={editPage?.hero_text || ''}
                            onChange={(e) =>
                              setEditPage({ ...editPage, hero_text: e.target.value })
                            }
                            rows={3}
                          />
                        </div>
                        <div>
                          <Label>Menu Order</Label>
                          <Input
                            type="number"
                            value={editPage?.menu_order || 0}
                            onChange={(e) =>
                              setEditPage({ ...editPage, menu_order: parseInt(e.target.value) })
                            }
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={editPage?.visible}
                            onCheckedChange={(checked) =>
                              setEditPage({ ...editPage, visible: checked })
                            }
                          />
                          <Label>Visible in Menu</Label>
                        </div>
                        <Button onClick={handleSave} className="w-full">
                          Update Page
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
};

export default PagesManagement;
