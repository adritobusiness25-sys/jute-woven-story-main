import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Mail, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

const InquiriesPage = () => {
  const [inquiries, setInquiries] = useState<any[]>([]);

  useEffect(() => {
    fetchInquiries();
  }, []);

  const fetchInquiries = async () => {
    const { data } = await supabase
      .from('inquiries')
      .select('*')
      .order('created_at', { ascending: false });
    setInquiries(data || []);
  };

  const toggleRead = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'read' ? 'unread' : 'read';
    await supabase.from('inquiries').update({ status: newStatus }).eq('id', id);
    toast.success(`Marked as ${newStatus}`);
    fetchInquiries();
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this inquiry?')) {
      await supabase.from('inquiries').delete().eq('id', id);
      toast.success('Inquiry deleted');
      fetchInquiries();
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-heading font-bold">Business Inquiries</h2>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Country</TableHead>
              <TableHead>Products</TableHead>
              <TableHead>Quantity</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {inquiries.map((inq) => (
              <TableRow key={inq.id}>
                <TableCell className="font-medium">{inq.name}</TableCell>
                <TableCell>{inq.email}</TableCell>
                <TableCell>{inq.country}</TableCell>
                <TableCell className="max-w-xs truncate">{inq.required_products}</TableCell>
                <TableCell>{inq.quantity}</TableCell>
                <TableCell>
                  <Badge variant={inq.status === 'read' ? 'secondary' : 'default'}>
                    {inq.status}
                  </Badge>
                </TableCell>
                <TableCell>{new Date(inq.created_at).toLocaleDateString()}</TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => toggleRead(inq.id, inq.status)}
                    >
                      <Mail className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(inq.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
};

export default InquiriesPage;
