import BlogCard from "@/components/BlogCard";
import heroImage from "@/assets/hero-jute-field.jpg";
import weavingImage from "@/assets/weaving-craft.jpg";
import bagsImage from "@/assets/product-bags.jpg";
import packagingImage from "@/assets/product-packaging.jpg";
import decorImage from "@/assets/product-decor.jpg";
import lifestyleImage from "@/assets/product-lifestyle.jpg";

const Blog = () => {
  const posts = [
    {
      id: "1",
      image: heroImage,
      title: "The Journey from Field to Fabric",
      excerpt: "Discover how our artisans transform raw jute into beautiful, sustainable products through traditional craftsmanship and modern innovation.",
      date: "March 15, 2025",
    },
    {
      id: "2",
      image: weavingImage,
      title: "Why Jute is the Future of Sustainable Living",
      excerpt: "Learn about the environmental benefits of choosing jute over synthetic materials and how it contributes to a circular economy.",
      date: "March 10, 2025",
    },
    {
      id: "3",
      image: bagsImage,
      title: "Supporting Local Farmers Through Fair Trade",
      excerpt: "How our commitment to ethical sourcing creates positive change in farming communities across Bangladesh.",
      date: "March 5, 2025",
    },
    {
      id: "4",
      image: packagingImage,
      title: "Sustainable Packaging Solutions for Modern Business",
      excerpt: "Explore how businesses are reducing their environmental footprint by switching to biodegradable jute packaging.",
      date: "February 28, 2025",
    },
    {
      id: "5",
      image: decorImage,
      title: "Bringing Natural Elegance to Your Home",
      excerpt: "Design inspiration and styling tips for incorporating jute décor into contemporary living spaces.",
      date: "February 22, 2025",
    },
    {
      id: "6",
      image: lifestyleImage,
      title: "The Art of Handloom Weaving",
      excerpt: "Meet the master weavers preserving centuries-old techniques while creating products for the modern world.",
      date: "February 15, 2025",
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-heading text-5xl md:text-6xl font-bold mb-4 animate-fade-in">
            Our Blog
          </h1>
          <p className="text-xl max-w-2xl mx-auto animate-slide-up">
            Stories, insights, and updates from the world of sustainable jute
          </p>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post, index) => (
              <div
                key={post.id}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <BlogCard {...post} />
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;
