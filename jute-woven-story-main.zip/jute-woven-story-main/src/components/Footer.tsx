import { Link } from "react-router-dom";
import { Mail, Phone, MapPin, Facebook, Instagram, Linkedin, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <h3 className="font-heading text-xl font-bold mb-4">Jute Source BD</h3>
            <p className="text-sm mb-4 opacity-90">
              Weaving nature into sustainable products for a better tomorrow.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-accent transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-heading text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-sm hover:text-accent transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/products" className="text-sm hover:text-accent transition-colors">
                  Our Products
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-sm hover:text-accent transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/faqs" className="text-sm hover:text-accent transition-colors">
                  FAQs
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-heading text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2 text-sm">
                <MapPin size={16} className="mt-1 flex-shrink-0" />
                <span>House # 16, Level 6, Road # 13<br />Sector # 4, Uttara<br />Dhaka, Bangladesh</span>
              </li>
              <li className="flex items-center space-x-2 text-sm">
                <Phone size={16} />
                <a href="tel:+8801713727871" className="hover:text-accent transition-colors">+88 01713 727871</a>
              </li>
              <li className="flex items-center space-x-2 text-sm">
                <Mail size={16} />
                <a href="mailto:info@jutesourcebd.com" className="hover:text-accent transition-colors">info@jutesourcebd.com</a>
              </li>
              <li className="flex items-center space-x-2 text-sm">
                <MapPin size={16} />
                <a href="https://jutesourcebd.com" target="_blank" rel="noopener noreferrer" className="hover:text-accent transition-colors">jutesourcebd.com</a>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="font-heading text-lg font-semibold mb-4">Newsletter</h3>
            <p className="text-sm mb-4 opacity-90">
              Subscribe to get updates on our latest products and offers.
            </p>
            <div className="flex flex-col space-y-2">
              <Input
                type="email"
                placeholder="Your email"
                className="bg-primary-foreground/10 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/50"
              />
              <Button variant="secondary" size="sm">
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-primary-foreground/20 pt-6 text-center">
          <p className="text-sm opacity-80">
            © 2025 Jute Source BD. All rights reserved. | Crafted with care for a sustainable future.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
