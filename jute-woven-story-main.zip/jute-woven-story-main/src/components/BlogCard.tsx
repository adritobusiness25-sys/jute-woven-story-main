import { Link } from "react-router-dom";
import { Calendar, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BlogCardProps {
  id: string;
  image: string;
  title: string;
  excerpt: string;
  date: string;
}

const BlogCard = ({ id, image, title, excerpt, date }: BlogCardProps) => {
  return (
    <div className="group bg-card rounded-lg overflow-hidden shadow-md transition-all duration-300 hover:shadow-xl">
      <div className="aspect-video overflow-hidden">
        <img
          src={image}
          alt={title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
      </div>
      <div className="p-6">
        <div className="flex items-center text-sm text-muted-foreground mb-3">
          <Calendar size={16} className="mr-2" />
          <span>{date}</span>
        </div>
        <h3 className="font-heading text-xl font-semibold mb-3 text-foreground group-hover:text-primary transition-colors">
          {title}
        </h3>
        <p className="text-muted-foreground mb-4 line-clamp-3">{excerpt}</p>
        <Link to={`/blog/${id}`}>
          <Button variant="link" className="p-0 h-auto font-semibold group/btn">
            Read More
            <ArrowRight size={16} className="ml-2 transition-transform group-hover/btn:translate-x-1" />
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default BlogCard;
