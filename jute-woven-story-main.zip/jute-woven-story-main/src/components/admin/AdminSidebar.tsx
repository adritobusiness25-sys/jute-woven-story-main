import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  FileEdit,
  Mail,
  MessageSquare,
  Settings,
  Users,
  Shield,
  Menu,
  LogOut,
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  useSidebar,
} from '@/components/ui/sidebar';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import logo from '@/assets/logo.jpg';

const menuItems = [
  { title: 'Dashboard', url: '/admin_cp', icon: LayoutDashboard },
  { title: 'Blog', url: '/admin_cp/blog', icon: FileText },
  { title: 'Pages', url: '/admin_cp/pages', icon: FileEdit },
  { title: 'Messages', url: '/admin_cp/messages', icon: Mail },
  { title: 'Inquiries', url: '/admin_cp/inquiries', icon: MessageSquare },
  { title: 'Settings', url: '/admin_cp/settings', icon: Settings },
  { title: 'Chatbox', url: '/admin_cp/chatbox', icon: MessageSquare },
  { title: 'Users', url: '/admin_cp/users', icon: Users },
  { title: 'Security', url: '/admin_cp/security', icon: Shield },
];

export function AdminSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const { signOut } = useAuth();
  
  const isCollapsed = state === 'collapsed';
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? 'bg-primary/10 text-primary font-medium' : 'hover:bg-accent';

  return (
    <Sidebar className={isCollapsed ? 'w-14' : 'w-60'} collapsible="icon">
      <SidebarContent>
        <div className="p-4 flex items-center gap-2 border-b">
          <img src={logo} alt="GoldenJute" className="h-8 w-8 rounded" />
          {!isCollapsed && <span className="font-heading font-bold text-lg">GoldenJute</span>}
        </div>

        <SidebarGroup>
          <SidebarGroupLabel>Main</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink to={item.url} end className={getNavCls}>
                      <item.icon className="h-4 w-4" />
                      {!isCollapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <div className="mt-auto p-4 border-t">
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={signOut}
          >
            <LogOut className="h-4 w-4" />
            {!isCollapsed && <span className="ml-2">Logout</span>}
          </Button>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}
