import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import logo from "@/assets/logo.jpg";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const aboutSubmenu = [
    { name: "Why Choose Us", path: "/why-choose-us" },
    { name: "Sustainability & Impact", path: "/sustainability" },
    { name: "Export & OEM Services", path: "/export-oem" },
    { name: "Work With Us", path: "/work-with-us" },
  ];

  const productsSubmenu = [
    { name: "Braiding Materials", path: "/braiding-materials" },
    { name: "Finished Products", path: "/finished-products" },
  ];

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "FAQs", path: "/faqs" },
    { name: "Blog", path: "/blog" },
    { name: "Inquiries", path: "/inquiries" },
    { name: "Contact", path: "/contact" },
  ];

  const isHomePage = location.pathname === "/";
  const shouldBeTransparent = isHomePage && !isScrolled;

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        shouldBeTransparent
          ? "bg-transparent"
          : "bg-primary shadow-lg"
      }`}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img 
              src={logo} 
              alt="Jute Source BD" 
              className="h-16 w-auto"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <Link
              to="/"
              className={`font-body font-medium transition-colors hover:text-accent ${
                location.pathname === "/"
                  ? "text-accent"
                  : shouldBeTransparent ? "text-card" : "text-primary-foreground"
              }`}
            >
              Home
            </Link>

            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <NavigationMenuTrigger 
                    className={`font-body font-medium bg-transparent hover:bg-transparent ${
                      shouldBeTransparent ? "text-card" : "text-primary-foreground"
                    }`}
                  >
                    About
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[300px] gap-2 p-4 bg-card">
                      {aboutSubmenu.map((item) => (
                        <li key={item.path}>
                          <NavigationMenuLink asChild>
                            <Link
                              to={item.path}
                              className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                            >
                              <div className="text-sm font-medium leading-none">{item.name}</div>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger 
                    className={`font-body font-medium bg-transparent hover:bg-transparent ${
                      shouldBeTransparent ? "text-card" : "text-primary-foreground"
                    }`}
                  >
                    Products
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[300px] gap-2 p-4 bg-card">
                      {productsSubmenu.map((item) => (
                        <li key={item.path}>
                          <NavigationMenuLink asChild>
                            <Link
                              to={item.path}
                              className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                            >
                              <div className="text-sm font-medium leading-none">{item.name}</div>
                            </Link>
                          </NavigationMenuLink>
                        </li>
                      ))}
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>

            {navLinks.filter(link => link.path !== "/").map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`font-body font-medium transition-colors hover:text-accent ${
                  location.pathname === link.path
                    ? "text-accent"
                    : shouldBeTransparent ? "text-card" : "text-primary-foreground"
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className={shouldBeTransparent ? "text-card" : "text-primary-foreground"} />
            ) : (
              <Menu className={shouldBeTransparent ? "text-card" : "text-primary-foreground"} />
            )}
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <div className="flex flex-col space-y-4">
              <Link
                to="/"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`font-body font-medium transition-colors hover:text-accent ${
                  location.pathname === "/"
                    ? "text-accent"
                    : shouldBeTransparent ? "text-card" : "text-primary-foreground"
                }`}
              >
                Home
              </Link>

              <div>
                <div className={`font-body font-medium mb-2 ${shouldBeTransparent ? "text-card" : "text-primary-foreground"}`}>
                  About
                </div>
                <div className="ml-4 space-y-2">
                  {aboutSubmenu.map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`block font-body text-sm transition-colors hover:text-accent ${
                        location.pathname === item.path
                          ? "text-accent"
                          : shouldBeTransparent ? "text-card/80" : "text-primary-foreground/80"
                      }`}
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              </div>

              <div>
                <div className={`font-body font-medium mb-2 ${shouldBeTransparent ? "text-card" : "text-primary-foreground"}`}>
                  Products
                </div>
                <div className="ml-4 space-y-2">
                  {productsSubmenu.map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`block font-body text-sm transition-colors hover:text-accent ${
                        location.pathname === item.path
                          ? "text-accent"
                          : shouldBeTransparent ? "text-card/80" : "text-primary-foreground/80"
                      }`}
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              </div>

              {navLinks.filter(link => link.path !== "/").map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`font-body font-medium transition-colors hover:text-accent ${
                    location.pathname === link.path
                      ? "text-accent"
                      : shouldBeTransparent ? "text-card" : "text-primary-foreground"
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;
