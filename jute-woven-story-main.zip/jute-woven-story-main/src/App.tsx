import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./hooks/useAuth";
import Navigation from "./components/Navigation";
import Footer from "./components/Footer";
import { useAnalytics } from "./hooks/useAnalytics";
import Home from "./pages/Home";
import WhyChooseUs from "./pages/WhyChooseUs";
import Sustainability from "./pages/Sustainability";
import ExportOEM from "./pages/ExportOEM";
import WorkWithUs from "./pages/WorkWithUs";
import BraidingMaterials from "./pages/BraidingMaterials";
import FinishedProducts from "./pages/FinishedProducts";
import FAQs from "./pages/FAQs";
import Blog from "./pages/Blog";
import Inquiries from "./pages/Inquiries";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";
import Auth from "./pages/Auth";
import AdminLayout from "./pages/admin/AdminLayout";
import Dashboard from "./pages/admin/Dashboard";
import BlogManagement from "./pages/admin/BlogManagement";
import PagesManagement from "./pages/admin/PagesManagement";
import MessagesPage from "./pages/admin/MessagesPage";
import InquiriesPage from "./pages/admin/InquiriesPage";
import SettingsPage from "./pages/admin/SettingsPage";
import ChatboxPage from "./pages/admin/ChatboxPage";
import UsersPage from "./pages/admin/UsersPage";
import SecurityPage from "./pages/admin/SecurityPage";

const queryClient = new QueryClient();

function AnalyticsWrapper({ children }: { children: React.ReactNode }) {
  useAnalytics();
  return <>{children}</>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <AnalyticsWrapper>
            <Routes>
              <Route path="/auth" element={<Auth />} />
              <Route path="/admin_cp" element={<AdminLayout />}>
                <Route index element={<Dashboard />} />
                <Route path="blog" element={<BlogManagement />} />
                <Route path="pages" element={<PagesManagement />} />
                <Route path="messages" element={<MessagesPage />} />
                <Route path="inquiries" element={<InquiriesPage />} />
                <Route path="settings" element={<SettingsPage />} />
                <Route path="chatbox" element={<ChatboxPage />} />
                <Route path="users" element={<UsersPage />} />
                <Route path="security" element={<SecurityPage />} />
              </Route>
              <Route path="/" element={<><Navigation /><Home /><Footer /></>} />
              <Route path="/why-choose-us" element={<><Navigation /><WhyChooseUs /><Footer /></>} />
              <Route path="/sustainability" element={<><Navigation /><Sustainability /><Footer /></>} />
              <Route path="/export-oem" element={<><Navigation /><ExportOEM /><Footer /></>} />
              <Route path="/work-with-us" element={<><Navigation /><WorkWithUs /><Footer /></>} />
              <Route path="/braiding-materials" element={<><Navigation /><BraidingMaterials /><Footer /></>} />
              <Route path="/finished-products" element={<><Navigation /><FinishedProducts /><Footer /></>} />
              <Route path="/faqs" element={<><Navigation /><FAQs /><Footer /></>} />
              <Route path="/blog" element={<><Navigation /><Blog /><Footer /></>} />
              <Route path="/inquiries" element={<><Navigation /><Inquiries /><Footer /></>} />
              <Route path="/contact" element={<><Navigation /><Contact /><Footer /></>} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AnalyticsWrapper>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
